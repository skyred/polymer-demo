<?php
/**
 * @file
 * Contains Drupal\twig_polymer\Asset\HTMLCollectionRenderer.
 */

namespace Drupal\twig_polymer\Asset;


use Drupal\Core\Asset\AssetCollectionRendererInterface;

class HTMLCollectionRenderer implements AssetCollectionRendererInterface {

}
