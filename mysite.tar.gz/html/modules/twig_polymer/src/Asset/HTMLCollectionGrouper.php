<?php
/**
 * @file
 * Contains Drupal\twig_polymer\Asset\HTMLCollectionGrouper.
 */

namespace Drupal\twig_polymer\Asset;


use Drupal\Core\Asset\AssetCollectionGrouperInterface;

class HTMLCollectionGrouper implements AssetCollectionGrouperInterface {

}
