<?php
/**
 * @file
 * Contains Drupal\twig_polymer\Exception\PolymerException.
 */

namespace Drupal\twig_polymer\Exception;

use Exception;

/**
 * General Polymer exceptions.
 */
class PolymerException
    extends Exception {}
