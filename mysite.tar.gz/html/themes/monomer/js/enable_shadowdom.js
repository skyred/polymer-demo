window.Polymer = {
  dom: 'shadow',
  lazyRegister: true
};