# Tutorial: Building a simple studio site with Monomer base theme in Drupal 8

## 

## Auto-collapse header

## Front page view with animation

## Content pages
